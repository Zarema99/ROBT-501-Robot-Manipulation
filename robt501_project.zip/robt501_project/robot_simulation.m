function robot_simulation(phi1, th1, phi2, th2, phi3, th3, L1, L2, d)
close all;

phi1 = deg2rad(phi1);
th1 = deg2rad(th1);
phi2 = deg2rad(phi2);
th2 = deg2rad(th2);
phi3 = deg2rad(phi3);
th3 = deg2rad(th3);
    
A1 = ScrewDisp(1,0,0,0,0,0,phi1,0);
A2 = ScrewDisp(0,1,0,0,0,0,th1,0);
A3 = ScrewDisp(1,0,0,0,0,L1,phi2,0);
A4 = ScrewDisp(0,1,0,0,0,L1,th2,0);
A5 = ScrewDisp(1,0,0,0,0,L1+L2,phi3,0);
A6 = ScrewDisp(0,1,0,0,0,L1+L2,th3,0);

%FORWARD KINEMATICS

%Second universal joint
A_R1 = A1*A2*A3*A4;
Pose_01 = [1 0 0 0; 0 1 0 0; 0 0 1 L1; 0 0 0 1];
Pose1 = A_R1*Pose_01;

%End-effector
A_R2 = A1*A2*A3*A4*A5*A6;
Pose_02 = [1 0 0 0; 0 1 0 0; 0 0 1 L1+L2; 0 0 0 1];
Pose2 = A_R2*Pose_02;

%Tendons (moving frame)
b1_0 = [d;0;L1+L2;1];
b2_0 = [-0.5*d; sqrt(3)/2*d; L1+L2; 1];
b3_0 = [-0.5*d; -sqrt(3)/2*d; L1+L2; 1];
b1_2 = A_R2*b1_0;
b2_2 = A_R2*b2_0;
b3_2 = A_R2*b3_0;

%INVERSE KINEMATICS  
    
%Coordinates of vectors a1-a3 w.r.t the fixed frame
a1 = [d;0;0];
a2 = [-0.5*d; sqrt(3)/2*d; 0];
a3 = [-0.5*d; -sqrt(3)/2*d; 0];

%Coordinates of vectors b1-b3 w.r.t the moving frame
b1 = [d;0;0];
b2 = [-0.5*d; sqrt(3)/2*d; 0];
b3 = [-0.5*d; -sqrt(3)/2*d; 0];
    
R = Pose2(1:3, 1:3);
q = Pose2(1:3, 4);

%Rotation matrix is multiplied with vectors b1-b3 to map them to the fixed
%frame
c1 = q + R*b1;
c2 = q + R*b2;
c3 = q + R*b3;
    
d1_sqrd = (c1 - a1)' * (c1 - a1);
d2_sqrd = (c2 - a2)' * (c2 - a2);
d3_sqrd = (c3 - a3)' * (c3 - a3);
    
d1 = sqrt(d1_sqrd);
disp("Value of d1 =")
disp(d1)
d2 = sqrt(d2_sqrd);
disp("Value of d2 =")
disp(d2)
d3 = sqrt(d3_sqrd);
disp("Value of d3 =")
disp(d3)

%PLOTS

figure(1)

%Home position

plot3 ( 0, 0, 0, 'o', 'MarkerFaceColor', 'b', 'MarkerEdgeColor', 'k', 'MarkerSize', 12 )
hold on
plot3 ( d, 0, 0, 'o', 'MarkerFaceColor', 'g', 'MarkerEdgeColor', 'k', 'MarkerSize', 6 )
text(d,0,L1, 'd1')
plot3 ( -0.5*d, sqrt(3)/2*d, 0, 'o', 'MarkerFaceColor', 'g', 'MarkerEdgeColor', 'k', 'MarkerSize', 6 )
text(-0.5*d,sqrt(3)/2*d,L1, 'd2')
plot3 ( -0.5*d, -sqrt(3)/2*d, 0, 'o', 'MarkerFaceColor', 'g', 'MarkerEdgeColor', 'k', 'MarkerSize', 6 )
text(-0.5*d,-sqrt(3)/2*d,L1, 'd3')
plot3( 0, 0, L1, 'o', 'MarkerFaceColor', 'b', 'MarkerEdgeColor', 'k', 'MarkerSize', 12 )
plot3( 0, 0, L1+L2, 'o', 'MarkerFaceColor', 'b', 'MarkerEdgeColor', 'k', 'MarkerSize', 12 )
plot3 ( d, 0, L1+L2, 'o', 'MarkerFaceColor', 'g', 'MarkerEdgeColor', 'k', 'MarkerSize', 6 )
plot3 ( -0.5*d, sqrt(3)/2*d, L1+L2, 'o', 'MarkerFaceColor', 'g', 'MarkerEdgeColor', 'k', 'MarkerSize', 6 )
plot3 ( -0.5*d, -sqrt(3)/2*d, L1+L2, 'o', 'MarkerFaceColor', 'g', 'MarkerEdgeColor', 'k', 'MarkerSize', 6 )
plot3 ( [ 0, 0 ],  [ 0, 0 ],  [ 0, L1 ], 'b', 'LineWidth', 3 )
plot3 ( [ 0, 0 ],  [ 0, 0],  [ L1, L1+L2 ], 'b', 'LineWidth', 3 )
plot3 ( [ d, d ],  [ 0, 0],  [ 0, L1+L2 ], 'r', 'LineWidth', 1 )
plot3 ( [ -0.5*d, -0.5*d ],  [ sqrt(3)/2*d, sqrt(3)/2*d],  [ 0, L1+L2 ], 'r', 'LineWidth', 1 )
plot3 ( [ -0.5*d, -0.5*d ],  [ -sqrt(3)/2*d, -sqrt(3)/2*d],  [ 0, L1+L2 ], 'r', 'LineWidth', 1 )

C = [0,0,0];   % center of circle 
R1 = d + 0.25;    % Radius of circle 
theta = 0:0.01:2*pi ;
x = C(1) + R1*cos(theta);
y = C(2) + R1*sin(theta);
z = C(3) + zeros(size(x));
patch(x,y,z,'y')
plot3(C(1),C(2),C(3),'r')

C = [0,0,L1+L2] ;   % center of circle 
R2 = d + 0.25;    % Radius of circle 
x = C(1) + R2*cos(theta);
y = C(2) + R2*sin(theta);
z = C(3) + zeros(size(x));
patch(x,y,z,'y')
plot3(C(1),C(2),C(3),'r')

%Frames
quiver3(0,0,0,1,0,0,'k')
text(1,0,0.25, 'X')
quiver3(0,0,0,0,1,0,'k')
text(0,1,0.25, 'Y')
quiver3(0,0,0,0,0,1,'k')
text(0,0,1, 'Z')

quiver3(0,0,L1+L2,1,0,0, 'k')
text(1,0,L1+L2+0.25, 'U')
quiver3(0,0,L1+L2,0,1,0, 'k')
text(0,1,L1+L2+0.25, 'V')
quiver3(0,0,L1+L2,0,0,1,'k')
text(0,0,L1+L2+1, 'W')

grid on
xlim([-5,5])
ylim([-5 5])
title('Simulation of the robot (home position)')

pause_seconds = 3.0;
hold off
pause ( pause_seconds );

%New pose

plot3 ( 0, 0, 0, 'o', 'MarkerFaceColor', 'b', 'MarkerEdgeColor', 'k', 'MarkerSize', 12 )
hold on
plot3 ( d, 0, 0, 'o', 'MarkerFaceColor', 'g', 'MarkerEdgeColor', 'k', 'MarkerSize', 6 )
text(d,0,0.1, 'd1')
plot3 ( -0.5*d, sqrt(3)/2*d, 0, 'o', 'MarkerFaceColor', 'g', 'MarkerEdgeColor', 'k', 'MarkerSize', 6 )
text(-0.5*d,sqrt(3)/2*d,0.1, 'd2')
plot3 ( -0.5*d, -sqrt(3)/2*d, 0, 'o', 'MarkerFaceColor', 'g', 'MarkerEdgeColor', 'k', 'MarkerSize', 6 )
text(-0.5*d,-sqrt(3)/2*d,0.1, 'd3')
plot3( Pose1(1,4), Pose1(2,4), Pose1(3,4), 'o', 'MarkerFaceColor', 'b', 'MarkerEdgeColor', 'k', 'MarkerSize', 12 )
plot3( Pose2(1,4), Pose2(2,4), Pose2(3,4), 'o', 'MarkerFaceColor', 'b', 'MarkerEdgeColor', 'k', 'MarkerSize', 12 )
plot3 ( b1_2(1), b1_2(2), b1_2(3), 'o', 'MarkerFaceColor', 'g', 'MarkerEdgeColor', 'k', 'MarkerSize', 6 )
plot3 ( b2_2(1), b2_2(2), b2_2(3), 'o', 'MarkerFaceColor', 'g', 'MarkerEdgeColor', 'k', 'MarkerSize', 6 )
plot3 ( b3_2(1), b3_2(2), b3_2(3), 'o', 'MarkerFaceColor', 'g', 'MarkerEdgeColor', 'k', 'MarkerSize', 6 )
plot3 ( [ 0, Pose1(1,4) ],  [ 0, Pose1(2,4) ],  [ 0, Pose1(3,4) ], 'b', 'LineWidth', 3 )
plot3 ( [ Pose1(1,4), Pose2(1,4) ],  [ Pose1(2,4), Pose2(2,4)],  [ Pose1(3,4), Pose2(3,4) ], 'b', 'LineWidth', 3 )
plot3 ( [ d, b1_2(1) ],  [ 0, b1_2(2) ], [ 0, b1_2(3) ], 'r', 'LineWidth', 1 )
plot3 ( [ -0.5*d, b2_2(1) ],  [ sqrt(3)/2*d, b2_2(2) ],  [ 0, b2_2(3) ], 'r', 'LineWidth', 1 )
plot3 ( [ -0.5*d, b3_2(1) ],  [ -sqrt(3)/2*d, b3_2(2) ],  [ 0, b3_2(3) ], 'r', 'LineWidth', 1 )
plot3 ( [ b1_2(1), b2_2(1) ],  [ b1_2(2), b2_2(2) ],  [ b1_2(3), b2_2(3) ], 'y', 'LineWidth', 3 )
plot3 ( [ b2_2(1), b3_2(1) ],  [ b2_2(2), b3_2(2) ],  [ b2_2(3), b3_2(3) ], 'y', 'LineWidth', 3 )
plot3 ( [ b1_2(1), b3_2(1) ],  [ b1_2(2), b3_2(2) ],  [ b1_2(3), b3_2(3) ], 'y', 'LineWidth', 3 )

C = [0,0,0] ;   % center of circle 
R1 = d+0.25;    % Radius of circle 
x = C(1) + R1*cos(theta);
y = C(2) + R1*sin(theta);
z = C(3) + zeros(size(x));
patch(x,y,z,'y')
plot3(C(1),C(2),C(3),'r')

%Frames

quiver3(0,0,0,1,0,0,'k')
text(1.25,0,0.05, 'X')
quiver3(0,0,0,0,1,0,'k')
text(0,1.25,0.05, 'Y')
quiver3(0,0,0,0,0,1,'k')
text(0,0,1, 'Z')

quiver3(Pose2(1,4),Pose2(2,4),Pose2(3,4),Pose2(1,1),Pose2(2,1),Pose2(3,1), 'k')
text(Pose2(1,1)+Pose2(1,4),Pose2(2,1)+Pose2(2,4),Pose2(3,1)+Pose2(3,4), 'U')
quiver3(Pose2(1,4),Pose2(2,4),Pose2(3,4),Pose2(1,2),Pose2(2,2),Pose2(3,2), 'k')
text(Pose2(1,2)+Pose2(1,4),Pose2(2,2)+Pose2(2,4),Pose2(3,2)+Pose2(3,4), 'V')
quiver3(Pose2(1,4),Pose2(2,4),Pose2(3,4),Pose2(1,3),Pose2(2,3),Pose2(3,3), 'k')
text(Pose2(1,3)+Pose2(1,4),Pose2(2,3)+Pose2(2,4),Pose2(3,3)+Pose2(3,4), 'W')

grid on
xlim([-5,5])
ylim([-5 5])
title('Simulation of the robot (new pose)')

