%The function takes as inputs screw axis, a point through it passes, and
%screw parameters (theta, t) and outputs the matrix for screw displacement

function A = ScrewDisp(sx,sy,sz,s0x,s0y,s0z,theta,t)

a11 = (sx^2-1)*(1-cos(theta)) + 1;
a12 = sx*sy*(1-cos(theta)) - sz*sin(theta);
a13 = sx*sz*(1-cos(theta)) + sy*sin(theta);
a14 = t*sx - s0x*(a11-1) - s0y*a12 - s0z*a13;
a21 = sy*sx*(1-cos(theta)) + sz*sin(theta);
a22 = (sy^2-1)*(1-cos(theta)) + 1;
a23 = sy*sz*(1-cos(theta)) - sx*sin(theta);
a24 = t*sy - s0x*a21 - s0y*(a22-1) - s0z*a23;
a31 = sz*sx*(1-cos(theta)) - sy*sin(theta);
a32 = sz*sy*(1-cos(theta)) + sx*sin(theta);
a33 = (sz^2-1)*(1-cos(theta)) + 1;
a34 = t*sz - s0x*a31 - s0y*a32 - s0z*(a33-1);

A = [a11 a12 a13 a14; a21 a22 a23 a24; a31 a32 a33 a34; 0 0 0 1];

end