clear;
close all;
clc;

syms th1 th2 th3 phi1 phi2 phi3
syms L1 L2
assume(th1, 'real')
assume(th2, 'real')
assume(th3, 'real')
assume(phi1, 'real')
assume(phi2, 'real')
assume(phi3, 'real')
assume(L1, 'real')
assume(L2, 'real')

%Screw parameter t = 0 for all screw displacements since the manipulator
%has only revolute joints

A1 = ScrewDisp(1,0,0,0,0,0,phi1,0);
disp("A1 =")
pretty(A1)
A2 = ScrewDisp(0,1,0,0,0,0,th1,0);
disp("A2 =")
pretty(A2)
A3 = ScrewDisp(1,0,0,0,0,L1,phi2,0);
disp("A3 =")
pretty(A3)
A4 = ScrewDisp(0,1,0,0,0,L1,th2,0);
disp("A4 =")
pretty(A4)
A5 = ScrewDisp(1,0,0,0,0,L1+L2,phi3,0);
disp("A5 =")
pretty(A5)
A6 = ScrewDisp(0,1,0,0,0,L1+L2,th3,0);
disp("A6 =")
pretty(A6)

%Pre-multiplication rule
A = simplify(A1*A2*A3*A4*A5*A6);
disp("Resultant A =")
disp(A)

%FORWARD KINEMATICS
Pose_0 = [1 0 0 0; 0 1 0 0; 0 0 1 L1+L2; 0 0 0 1];
Pose = simplify(A*Pose_0);
disp("Forward Kinematics:")
disp(Pose)
 
%INVERSE KINEMATICS 
syms qx qy qz ux uy uz vx vy vz wx wy wz d
assume(qx, 'real')
assume(qy, 'real')
assume(qz, 'real')
assume(ux, 'real')
assume(uy, 'real')
assume(uz, 'real')
assume(vx, 'real')
assume(vy, 'real')
assume(vz, 'real')
assume(wx, 'real')
assume(wy, 'real')
assume(wz, 'real')
assume(d, 'real')

Target = [ux vx wx qx; uy vy wy qy; uz vz wz qz; 0 0 0 1];
   
%Coordinates of vectors a1-a3 w.r.t the fixed frame
a1 = [d;0;0];
a2 = [-0.5*d; sqrt(3)/2*d; 0];
a3 = [-0.5*d; -sqrt(3)/2*d; 0];

%Coordinates of vectors b1-b3 w.r.t the moving frame
b1 = [d;0;0];
b2 = [-0.5*d; sqrt(3)/2*d; 0];
b3 = [-0.5*d; -sqrt(3)/2*d; 0];

%Solution in terms of qx-qz, ux-uz, etc.

R_simp = Target(1:3, 1:3);
q_simp = Target(1:3, 4);

%Rotation matrix is multiplied with vectors b1-b3 to map them to the fixed
%frame
c1_simp = q_simp + R_simp*b1;
c2_simp = q_simp + R_simp*b2;
c3_simp = q_simp + R_simp*b3;

d1_sqrd_simp = (c1_simp - a1)' * (c1_simp - a1);
d2_sqrd_simp = (c2_simp - a2)' * (c2_simp - a2);
d3_sqrd_simp = (c3_simp - a3)' * (c3_simp - a3);

d1_simp = simplify(sqrt(d1_sqrd_simp));
disp("d1_simp =")
disp(d1_simp)
d2_simp = simplify(sqrt(d2_sqrd_simp));
disp("d2_simp =")
disp(d2_simp)
d3_simp = simplify(sqrt(d3_sqrd_simp));
disp("d3_simp =")
disp(d3_simp)

%Solution in terms of phi1-phi3, th1-th3, L1, L2
    
R = Pose(1:3, 1:3);
q = Pose(1:3, 4);

%Rotation matrix is multiplied with vectors b1-b3 to map them to the fixed
%frame
c1 = q + R*b1;
c2 = q + R*b2;
c3 = q + R*b3;
    
d1_sqrd = (c1 - a1)' * (c1 - a1);
d2_sqrd = (c2 - a2)' * (c2 - a2);
d3_sqrd = (c3 - a3)' * (c3 - a3);
    
d1 = simplify(sqrt(d1_sqrd));
disp("d1 =")
disp(d1)
d2 = simplify(sqrt(d2_sqrd));
disp("d2 =")
disp(d2)
d3 = simplify(sqrt(d3_sqrd));
disp("d3 =")
disp(d3)
    


